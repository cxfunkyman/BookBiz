﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookBiz.BLL
{
    public class Publisher
    {
        private string vId, vPublisherName;

        public string Id 
        {
            get => vId;
            set => vId = value; 
        }

        public string PublisherName 
        {
            get => vPublisherName;
            set => vPublisherName = value; 
        }
    }
}
