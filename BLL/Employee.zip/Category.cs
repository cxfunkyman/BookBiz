﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookBiz.BLL
{
    public class Category
    {
        private string vId, vCategoryName;

        public string Id 
        {
            get => vId;
            set => vId = value; 
        }

        public string CategoryName 
        {
            get => vCategoryName;
            set => vCategoryName = value; 
        }
    }
}
