﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookBiz.BLL
{
    public class Book
    {
        private string vId, vISBN, vTitle, vUnitPrice, vQOH, vCategory;
        private DateTime vYearOfPublish;
        private List<Author> vAuthors;
        private Publisher vPublisher;

        public string Id 
        {
            get => vId;
            set => vId = value; 
        }

        public string ISBN 
        {
            get => vISBN;
            set => vISBN = value; 
        }

        public string Title 
        {
            get => vTitle;
            set => vTitle = value; 
        }

        public string UnitPrice 
        {
            get => vUnitPrice;
            set => vUnitPrice = value; 
        }

        public DateTime YearOfPublish 
        {
            get => vYearOfPublish;
            set => vYearOfPublish = value; 
        }

        public string QOH 
        {
            get => vQOH;
            set => vQOH = value; 
        }

        public List<Author> Authors 
        {
            get => vAuthors;
            set => vAuthors = value; 
        }

        public string Category 
        {
            get => vCategory;
            set => vCategory = value; 
        }

        public Publisher Publisher 
        {
            get => vPublisher;
            set => vPublisher = value; 
        }
    }
}
